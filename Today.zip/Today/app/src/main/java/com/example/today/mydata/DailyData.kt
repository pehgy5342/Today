package com.example.today.mydata

class DailyData {

    data class Daily(
        var title: String = "", var content: String = ""
    )


}