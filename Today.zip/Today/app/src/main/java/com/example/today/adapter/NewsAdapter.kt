package com.example.today.adapter

class NewsAdapter {
}