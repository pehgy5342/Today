package com.example.today.mydata

class API {
    val WeatherAPI = "https://opendata.cwb.gov.tw/api/v1/rest/datastore/F-D0047-089?Authorization=CWB-90DBCF96-212D-4C56-A245-F6D801358853&elementName=Wx,AT,T,CI,PoP6h"
    val WeatherWeekAPI = "https://opendata.cwb.gov.tw/api/v1/rest/datastore/F-D0047-091?Authorization=CWB-90DBCF96-212D-4C56-A245-F6D801358853&elementName=PoP12h,T"
    val ConstellationAPI = "https://horoscope-crawler.herokuapp.com/api/horoscope"
    val NewsAPI ="http://newsapi.org/v2/top-headlines?country=tw&apiKey=c5ad9c5ceb4a4eb4b9c1dce2d41ce0bf"
    val earthquakeAPI = ""


}
